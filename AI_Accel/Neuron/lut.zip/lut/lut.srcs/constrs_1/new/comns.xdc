#################################################
# Clock
#################################################
set_property PACKAGE_PIN F14 [get_ports clk]
set_property IOSTANDARD LVCMOS33 [get_ports clk]
create_clock -period 10.000 -name sys_clk [get_ports clk]

#################################################
# Reset Button
#################################################
set_property PACKAGE_PIN J2 [get_ports rst]
set_property IOSTANDARD LVCMOS33 [get_ports rst]

#################################################
# Start Button
#################################################
set_property PACKAGE_PIN J5 [get_ports start]
set_property IOSTANDARD LVCMOS33 [get_ports start]

#################################################
# X_IN[15:0] -> Slide Switches
#################################################
set_property PACKAGE_PIN V2 [get_ports {X_IN[0]}]
set_property PACKAGE_PIN U2 [get_ports {X_IN[1]}]
set_property PACKAGE_PIN U1 [get_ports {X_IN[2]}]
set_property PACKAGE_PIN T2 [get_ports {X_IN[3]}]
set_property PACKAGE_PIN T1 [get_ports {X_IN[4]}]
set_property PACKAGE_PIN R2 [get_ports {X_IN[5]}]
set_property PACKAGE_PIN R1 [get_ports {X_IN[6]}]
set_property PACKAGE_PIN P2 [get_ports {X_IN[7]}]
set_property PACKAGE_PIN P1 [get_ports {X_IN[8]}]
set_property PACKAGE_PIN N2 [get_ports {X_IN[9]}]
set_property PACKAGE_PIN N1 [get_ports {X_IN[10]}]
set_property PACKAGE_PIN M2 [get_ports {X_IN[11]}]
set_property PACKAGE_PIN M1 [get_ports {X_IN[12]}]
set_property PACKAGE_PIN L1 [get_ports {X_IN[13]}]
set_property PACKAGE_PIN K2 [get_ports {X_IN[14]}]
set_property PACKAGE_PIN K1 [get_ports {X_IN[15]}]

set_property IOSTANDARD LVCMOS33 [get_ports X_IN[*]]

#################################################
# Tie upper X_IN bits low
# (or connect to PMOD later)
#################################################

#################################################
# Y_OUT[15:0] -> LEDs
#################################################
set_property PACKAGE_PIN G1 [get_ports {Y_OUT[0]}]
set_property PACKAGE_PIN G2 [get_ports {Y_OUT[1]}]
set_property PACKAGE_PIN F1 [get_ports {Y_OUT[2]}]
set_property PACKAGE_PIN F2 [get_ports {Y_OUT[3]}]
set_property PACKAGE_PIN E1 [get_ports {Y_OUT[4]}]
set_property PACKAGE_PIN E2 [get_ports {Y_OUT[5]}]
set_property PACKAGE_PIN E3 [get_ports {Y_OUT[6]}]
set_property PACKAGE_PIN E5 [get_ports {Y_OUT[7]}]
set_property PACKAGE_PIN E6 [get_ports {Y_OUT[8]}]
set_property PACKAGE_PIN C3 [get_ports {Y_OUT[9]}]
set_property PACKAGE_PIN B2 [get_ports {Y_OUT[10]}]
set_property PACKAGE_PIN A2 [get_ports {Y_OUT[11]}]
set_property PACKAGE_PIN B3 [get_ports {Y_OUT[12]}]
set_property PACKAGE_PIN A3 [get_ports {Y_OUT[13]}]
set_property PACKAGE_PIN B4 [get_ports {Y_OUT[14]}]
set_property PACKAGE_PIN A4 [get_ports {Y_OUT[15]}]

set_property IOSTANDARD LVCMOS33 [get_ports Y_OUT[*]]

#################################################
# Done -> RGB0 Green
#################################################
set_property PACKAGE_PIN V4 [get_ports done]
set_property IOSTANDARD LVCMOS33 [get_ports done]

#################################################
# Debug State -> RGB1 LEDs
#################################################
set_property PACKAGE_PIN U3 [get_ports {dbg_state[0]}]
set_property PACKAGE_PIN V3 [get_ports {dbg_state[1]}]
set_property PACKAGE_PIN V5 [get_ports {dbg_state[2]}]

set_property IOSTANDARD LVCMOS33 [get_ports dbg_state[*]]

#################################################
# Configuration Voltage
#################################################
set_property CFGBVS VCCO [current_design]
set_property CONFIG_VOLTAGE 3.3 [current_design]